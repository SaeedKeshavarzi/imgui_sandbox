#include "imgui.h"
#include "implot.h"
#include "ImGuiFileBrowser.h"

static void file_browser_buttons();

void main_ui(ImVec4& clear_color)
{
    static bool show_demo_window = true;
    static bool show_implot_demo_window = true;
    static bool show_another_window = false;

    // 1. Show the big demo window (Most of the sample code is in ImGui::ShowDemoWindow()! You can browse its code to learn more about Dear ImGui!).
    if (show_demo_window)
        ImGui::ShowDemoWindow(&show_demo_window);

    if (show_implot_demo_window)
        ImPlot::ShowDemoWindow(&show_implot_demo_window);

    // 2. Show a simple window that we create ourselves. We use a Begin/End pair to created a named window.
    {
        static float f = 0.0f;
        static int counter = 0;

        ImGui::Begin("Hello, world!");                          // Create a window called "Hello, world!" and append into it.

        ImGui::Text("This is some useful text.");               // Display some text (you can use a format strings too)
        ImGui::Checkbox("Demo Window", &show_demo_window);      // Edit bools storing our window open/close state
        ImGui::Checkbox("ImPlot Demo Window", &show_implot_demo_window);
        ImGui::Checkbox("Another Window", &show_another_window);

        file_browser_buttons();
        ImGui::NewLine();

        ImGui::SliderFloat("float", &f, 0.0f, 1.0f);            // Edit 1 float using a slider from 0.0f to 1.0f
        ImGui::ColorEdit3("clear color", (float*)&clear_color); // Edit 3 floats representing a color

        if (ImGui::Button("Button"))                            // Buttons return true when clicked (most widgets return true when edited/activated)
            counter++;
        ImGui::SameLine();
        ImGui::Text("counter = %d", counter);

        ImGui::Text("Application average %.3f ms/frame (%.1f FPS)", 1000.0f / ImGui::GetIO().Framerate, ImGui::GetIO().Framerate);
        ImGui::End();
    }

    // 3. Show another simple window.
    if (show_another_window)
    {
        ImGui::Begin("Another Window", &show_another_window);   // Pass a pointer to our bool variable (the window will have a closing button that will clear the bool when clicked)
        ImGui::Text("Hello from another window!");
        if (ImGui::Button("Close Me"))
            show_another_window = false;
        ImGui::End();
    }
}

// https://github.com/gallickgunner/ImGui-Addons
static void file_browser_buttons()
{
    static imgui_addons::ImGuiFileBrowser file_dialog; // As a class member or globally
    static std::string path{ "" };
    static std::string name{ "" };
    static std::string extention{ "" };

    ImGui::PushID("ImGui-Addons");

    ImGui::Text("ImGui-Addons:");
    ImGui::Indent();

    if (ImGui::Button("Open File"))
        ImGui::OpenPopup("Open File Browser");

    ImGui::SameLine();
    if (ImGui::Button("Save File"))
        ImGui::OpenPopup("Save File Browser");

    ImGui::SameLine();
    if (ImGui::Button("Select Directory"))
        ImGui::OpenPopup("Select Directory Browser");

    ImGui::Unindent();

    if (file_dialog.showFileDialog("Open File Browser", imgui_addons::ImGuiFileBrowser::DialogMode::OPEN, ImVec2(700, 310), ".rar,.zip,.7z"))
    {
        name = file_dialog.selected_fn;
        path = file_dialog.selected_path;
        extention = file_dialog.ext;
        ImGui::OpenPopup("Result");
    }

    if (file_dialog.showFileDialog("Save File Browser", imgui_addons::ImGuiFileBrowser::DialogMode::SAVE, ImVec2(700, 310), ".cpp,.h,.hpp"))
    {
        name = file_dialog.selected_fn;
        path = file_dialog.selected_path;
        extention = file_dialog.ext;
        ImGui::OpenPopup("Result");
    }

    if (file_dialog.showFileDialog("Select Directory Browser", imgui_addons::ImGuiFileBrowser::DialogMode::SELECT, ImVec2(700, 310)))
    {
        name = file_dialog.selected_fn;
        path = file_dialog.selected_path;
        extention = "?";
        ImGui::OpenPopup("Result");
    }

    if (ImGui::BeginPopupModal("Result", NULL, ImGuiWindowFlags_AlwaysAutoResize))
    {
        ImGui::Text("Path: %s", path.c_str());
        ImGui::Text("Name: %s", name.c_str());
        if (extention != "?")
            ImGui::Text("Extention: %s", extention.c_str());
        
        if (ImGui::Button("OK"))
            ImGui::CloseCurrentPopup();

        ImGui::EndPopup();
    }

    ImGui::PopID();
}
